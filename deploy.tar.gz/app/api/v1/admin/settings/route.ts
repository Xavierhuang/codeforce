import { NextRequest, NextResponse } from 'next/server'
import { requireRole } from '@/lib/auth-helpers'
import { prisma } from '@/lib/prisma'

export const dynamic = 'force-dynamic'

// POST - Save platform settings
export async function POST(req: NextRequest) {
  try {
    const admin = await requireRole('ADMIN')
    const body = await req.json()
    const { platformFeeRate, platformName, supportEmail, announcement } = body

    // TODO: Store settings in database (create a Settings model)
    // For now, we'll just validate and return success
    // In production, you'd want to store these in a Settings table

    if (announcement && announcement.trim()) {
      // Send announcement notification to all users
      const allUsers = await prisma.user.findMany({
        select: { id: true },
      })

      await Promise.all(
        allUsers.map((user) =>
          prisma.notification.create({
            data: {
              userId: user.id,
              type: 'platform_announcement',
              message: announcement,
            },
          })
        )
      )
    }

    return NextResponse.json({
      message: 'Settings saved successfully',
      settings: {
        platformFeeRate,
        platformName,
        supportEmail,
      },
    })
  } catch (error: any) {
    console.error('Error saving settings:', error)
    if (error.message === 'Unauthorized' || error.message === 'Forbidden') {
      return NextResponse.json(
        { error: error.message },
        { status: error.message === 'Unauthorized' ? 401 : 403 }
      )
    }
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// GET - Get platform settings
export async function GET(req: NextRequest) {
  try {
    const admin = await requireRole('ADMIN')

    // TODO: Fetch from Settings table
    // For now, return defaults
    return NextResponse.json({
      platformFeeRate: process.env.STRIPE_PLATFORM_FEE_RATE || '0.15',
      platformName: 'Skillyy',
      supportEmail: 'support@skillyy.com',
    })
  } catch (error: any) {
    console.error('Error fetching settings:', error)
    if (error.message === 'Unauthorized' || error.message === 'Forbidden') {
      return NextResponse.json(
        { error: error.message },
        { status: error.message === 'Unauthorized' ? 401 : 403 }
      )
    }
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}


