'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function AdminDashboardPage() {
  const router = useRouter()

  useEffect(() => {
    // Redirect to stats page by default
    router.replace('/admin/stats')
  }, [router])

  return (
    <div className="p-8">
      <div className="text-center">Redirecting...</div>
    </div>
  )
}
