import { TaskCreateForm } from '@/components/TaskCreateForm'

export default function NewTaskPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <TaskCreateForm />
    </div>
  )
}

