'use client'

import { usePathname } from 'next/navigation'
import Link from 'next/link'
import { 
  LayoutDashboard, 
  Users, 
  ClipboardList, 
  DollarSign, 
  MessageSquare,
  ShieldCheck,
  AlertCircle,
  Settings,
  AlertTriangle
} from 'lucide-react'
import useSWR from 'swr'
import { Badge } from '@/components/ui/badge'

const fetcher = (url: string) => fetch(url).then((res) => res.json())

interface NavItem {
  href: string
  label: string
  icon: React.ComponentType<{ className?: string }>
  badge?: number
  badgeColor?: string
}

export function AdminSidebar() {
  const pathname = usePathname()

  // Fetch counts for badges
  const { data: pendingUsers } = useSWR('/api/v1/admin/users', fetcher)
  const { data: payoutRequests } = useSWR('/api/v1/payouts/request', fetcher)
  const { data: supportTickets } = useSWR('/api/v1/admin/support', fetcher)

  const pendingVerifications = pendingUsers?.filter((u: any) => u.verificationStatus === 'PENDING').length || 0
  const pendingPayouts = payoutRequests?.filter((r: any) => r.status === 'PENDING').length || 0
  const openTickets = supportTickets?.filter((t: any) => t.status === 'OPEN' || t.status === 'IN_PROGRESS').length || 0
  const reports = supportTickets?.filter((t: any) => 
    t.category === 'REPORT_USER' || t.category === 'REPORT_TASK'
  ) || []

  const navItems: NavItem[] = [
    {
      href: '/admin/stats',
      label: 'Statistics',
      icon: LayoutDashboard,
    },
    {
      href: '/admin/users',
      label: 'Users',
      icon: Users,
    },
    {
      href: '/admin/verifications',
      label: 'Verifications',
      icon: ShieldCheck,
      badge: pendingVerifications,
      badgeColor: 'bg-red-500',
    },
    {
      href: '/admin/tasks',
      label: 'Tasks',
      icon: ClipboardList,
    },
    {
      href: '/admin/payouts',
      label: 'Payout Requests',
      icon: DollarSign,
      badge: pendingPayouts,
      badgeColor: 'bg-yellow-500',
    },
    {
      href: '/admin/support',
      label: 'Support',
      icon: MessageSquare,
      badge: openTickets,
      badgeColor: 'bg-blue-500',
    },
    {
      href: '/admin/settings',
      label: 'Settings',
      icon: Settings,
    },
    {
      href: '/admin/reports',
      label: 'Reports',
      icon: AlertTriangle,
      badge: reports?.filter((r: any) => r.status === 'OPEN').length || 0,
      badgeColor: 'bg-red-500',
    },
    {
      href: '/admin/compliance',
      label: 'Compliance',
      icon: ShieldCheck,
    },
  ]

  return (
    <aside className="hidden md:flex w-64 border-r bg-card flex-col fixed left-0 top-0 h-screen z-40">
      <div className="p-6 border-b">
        <Link href="/admin/stats" className="flex items-center">
          <img src="/logo.svg" alt="Skillyy" className="h-8 w-auto" />
          <span className="ml-2 text-sm font-semibold text-muted-foreground">Admin</span>
        </Link>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href || (item.href !== '/admin/stats' && pathname?.startsWith(item.href))
          
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={`flex items-center justify-between gap-3 px-3 py-2 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-5 h-5" />
                  <span className="text-sm font-medium">{item.label}</span>
                </div>
                {item.badge !== undefined && item.badge > 0 && (
                  <Badge className={`${item.badgeColor || 'bg-primary'} text-white text-xs min-w-[20px] flex items-center justify-center`}>
                    {item.badge > 99 ? '99+' : item.badge}
                  </Badge>
                )}
              </div>
            </Link>
          )
        })}
      </nav>

      <div className="p-4 border-t">
        <Link href="/dashboard">
          <div className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-accent text-muted-foreground hover:text-foreground transition-colors">
            <LayoutDashboard className="w-5 h-5" />
            <span className="text-sm font-medium">User Dashboard</span>
          </div>
        </Link>
      </div>
    </aside>
  )
}

